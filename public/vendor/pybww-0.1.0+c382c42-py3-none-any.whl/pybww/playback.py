"""Schedule the interpreted score and synthesize chanter audio."""

import math
import re
import sys
import wave
from array import array
from collections.abc import Iterator
from io import BytesIO
from itertools import pairwise
from typing import get_args

from .embellishments import grace_notes_before_beat
from .models import Embellishment, Note, PlaybackSound, Tune

_SAMPLE_RATE = 22_050
_TABLE_SIZE = 512
_NATURAL_MIDI = dict(zip(("LG", "LA", "B", "C", "D", "E", "F", "HG", "HA"),
                         (67, 69, 71, 72, 74, 76, 77, 79, 81), strict=True))
_ACCIDENTALS = {"sharp": 1, "flat": -1, "natural": 0}
_PITCH_INDEX = {pitch: index for index, pitch in enumerate(_NATURAL_MIDI)}
_FREQUENCY_BANK = {-1: 0, 1: 9, 0: 18}
_CUT_REDUCTION = {"strathspey": 0.5, "reel": 0.25}
_COMPOUND_METERS = {(6, 8), (9, 8), (12, 8)}
_WrittenNote = tuple[Note, dict[str, int], int]
_Event = tuple[float, float]


def _frequency_mappings(tune: Tune) -> tuple[int, ...] | None:
    values = tune.frequency_mappings
    if values and len(values) == 27 and all(0 < hz < _SAMPLE_RATE / 2 for hz in values):
        return values
    return None


def _frequency(pitch: str, accidental: int, mappings: tuple[int, ...] | None) -> float:
    if mappings is not None:
        return mappings[_FREQUENCY_BANK[accidental] + _PITCH_INDEX[pitch]]
    midi = _NATURAL_MIDI[pitch] + accidental
    return 440 * 2 ** ((midi - 69) / 12)


def _grace_duration_index(movement: Embellishment, pitch: str, piobaireachd: bool) -> int:
    if movement.code in ("chedare", "chedari"):
        return 2
    # Use the longer duration for the low G cuts in bottom-hand movements.
    extended = pitch == "LG" and movement.category in ("grip", "throw", "taorluath")
    return (2 if piobaireachd else 0) + int(extended)


def _measure_order(tune: Tune, count: int) -> Iterator[int]:
    cursor = 0
    for repeat in tune.repeats:
        yield from range(cursor, repeat.stop_measure)
        first_ending = next((ending for ending in repeat.endings if ending.number == 1), None)
        yield from range(repeat.start_measure,
                         first_ending.start_measure if first_ending else repeat.stop_measure)
        # Any second ending immediately follows the repeat in written order.
        cursor = repeat.stop_measure
    yield from range(cursor, count)


def _written_measures(tune: Tune) -> list[list[_WrittenNote]]:
    keys = {(change.measure_index, change.note_index): change.key_signature
            for change in tune.signature_changes if change.key_signature is not None}
    if tune.key_signature is not None:
        keys.setdefault((0, 0), tune.key_signature)
    meters = {(change.measure_index, change.note_index): change.meter
              for change in tune.signature_changes if change.meter is not None}
    key: dict[str, int] = {}
    meter = tune.meter
    written = []
    measures = (measure for part in tune.parts for measure in part.measures)
    for measure_index, measure in enumerate(measures):
        written_notes = []
        for note_index in range(len(measure.notes) + 1):
            position = (measure_index, note_index)
            meter = meters.get(position, meter)
            signature = keys.get(position)
            if signature is not None:
                key = {accidental[len(prefix):].upper(): offset
                       for accidental in signature
                       for prefix, offset in _ACCIDENTALS.items() if accidental.startswith(prefix)}
            if note_index < len(measure.notes):
                # A whole note spans 8/3 dotted-quarter beats or 4 quarter beats.
                seconds_at_one_bpm = 160 if meter in _COMPOUND_METERS else 240
                written_notes.append((measure.notes[note_index], key, seconds_at_one_bpm))
        written.append(written_notes)
    return written


def _measure_durations(notes: list[_WrittenNote], bpm: float,
                       cut_reduction: float) -> list[float]:
    durations = [float(note.duration if note.duration is not None else note.base_duration)
                 * seconds_at_one_bpm / bpm for note, _, seconds_at_one_bpm in notes]
    if not cut_reduction:
        return durations

    next_pair_start = 0
    for index, ((first, _, first_scale), (second, _, second_scale)) in enumerate(pairwise(notes)):
        if index < next_pair_start:
            continue
        dotted, cut = (first, second) if first.dot_count else (second, first)
        if (first_scale != second_scale or dotted.dot_count != 1 or cut.dot_count
                or dotted.tuplet or cut.tuplet
                or dotted.duration is None or cut.duration is None
                or dotted.duration != 3 * cut.duration):
            continue

        long_index, short_index = (index, index + 1) if first.dot_count else (index + 1, index)
        # Move time within the pair so the following note still starts as written.
        transfer = durations[short_index] * cut_reduction
        durations[long_index] += transfer
        durations[short_index] -= transfer
        next_pair_start = index + 2
    return durations


def _events(tune: Tune, bpm: float | None, grace_ms: float | None) -> list[_Event]:
    bpm = bpm if bpm is not None else (tune.tempo if tune.tempo is not None else 90)
    if not math.isfinite(bpm) or bpm <= 0:
        raise ValueError("bpm must be finite and positive")
    if grace_ms is not None and (not math.isfinite(grace_ms) or grace_ms < 0):
        raise ValueError("grace_ms must be finite and nonnegative")

    written = _written_measures(tune)
    order = list(_measure_order(tune, len(written)))
    notes = [entry for index in order for entry in written[index]]
    if not notes:
        raise ValueError("tune has no notes to play")

    tune_type = tune.tune_type or ""
    cut_reduction = next(
        (reduction for name, reduction in _CUT_REDUCTION.items()
         if re.search(rf"\b{name}s?\b", tune_type, re.IGNORECASE)),
        0.0,
    )
    written_durations = [_measure_durations(measure, bpm, cut_reduction) for measure in written]
    durations = [duration for index in order for duration in written_durations[index]]
    grace_durations = tune.gracenote_durations if grace_ms is None else None
    if grace_durations is None:
        grace_durations = (25 if grace_ms is None else grace_ms,) * 4
    piobaireachd = bool(re.search(r"\b(?:piobaireachd|pibroch)\b", tune_type, re.IGNORECASE))
    mappings = _frequency_mappings(tune)
    before_beat: list[list[_Event]] = []
    on_beat: list[list[_Event]] = []
    melody: list[float] = []
    for note, key, _ in notes:
        before: list[_Event] = []
        after: list[_Event] = []
        for movement in note.embellishments:
            graces = []
            for pitch in movement.grace_pitches or ():
                index = _grace_duration_index(movement, pitch, piobaireachd)
                duration_ms = grace_durations[index]
                graces.append((_frequency(pitch, key.get(pitch, 0), mappings), duration_ms / 1000))
            split = grace_notes_before_beat(movement)
            before.extend(grace for grace in graces[:split] if grace[1])
            after.extend(grace for grace in graces[split:] if grace[1])
        before_beat.append(before)
        on_beat.append(after)
        melody.append(_frequency(note.pitch, key.get(note.pitch, 0), mappings))

    events = before_beat[0].copy()
    before_beat.append([])
    ties = {(tie.source, tie.target) for tie in tune.ties}
    for index, ((note, _, _), pitch, duration) in enumerate(zip(notes, melody, durations, strict=True)):
        after = on_beat[index]
        upcoming = before_beat[index + 1]
        requested = sum(grace for _, grace in (*after, *upcoming))
        # Share the available time across both movements and leave the melody audible.
        scale = min(1, duration / (2 * requested)) if requested else 1
        held = duration - requested * scale
        events.extend((frequency, grace * scale) for frequency, grace in after)
        if (index and not before_beat[index] and not after and melody[index - 1] == pitch
                and (notes[index - 1][0].token, note.token) in ties):
            _, previous_duration = events[-1]
            events[-1] = (pitch, previous_duration + held)
        else:
            events.append((pitch, held))
        events.extend((frequency, grace * scale) for frequency, grace in upcoming)
    return events


def _reed_wave(frequency: float, *, bright: bool) -> tuple[float, ...]:
    """Build one cycle from a saw and a narrow pulse an octave above it."""
    resonance_center, resonance_width, resonance_gain, cutoff = (
        (3650, 1150, 5.5, 8200) if bright else (2500, 850, 1.8, 4700)
    )
    harmonics = []
    for harmonic in range(1, math.ceil(_SAMPLE_RATE / (2 * frequency))):
        saw = (-1) ** (harmonic + 1) * 0.65 / harmonic
        pulse = 0.0
        if harmonic % 2 == 0:
            # Fourier coefficient of a centered, 22% duty-cycle pulse.
            pulse = 0.9 * math.sin(math.pi * 0.22 * harmonic / 2) / (harmonic / 2)
        hz = harmonic * frequency
        # A broad upper-mid resonance gives the reed its nasal edge.
        distance = (hz - resonance_center) / resonance_width
        resonance = 1 + resonance_gain * math.exp(-0.5 * distance ** 2)
        rolloff = 1 / (1 + (hz / cutoff) ** 4)
        gain = resonance * rolloff
        harmonics.append((math.tau * harmonic / _TABLE_SIZE, saw * gain, pulse * gain))
    cycle = [sum(saw * math.sin(step * index) + pulse * math.cos(step * index)
                 for step, saw, pulse in harmonics)
             for index in range(_TABLE_SIZE)]
    peak = max(abs(sample) for sample in cycle)
    return tuple(18_000 * sample / peak for sample in cycle)


def _wave_sample(table: tuple[float, ...], phase: float) -> float:
    index = int(phase)
    fraction = phase - index
    return table[index] + fraction * (table[(index + 1) % _TABLE_SIZE] - table[index])


def _drone_samples(low_a: int) -> tuple[float, ...]:
    # Bass and tenor sit two octaves and one octave below the chanter's low A.
    bass_hz = low_a / 4
    period = 4 * _SAMPLE_RATE // math.gcd(4 * _SAMPLE_RATE, low_a)
    step = math.tau * bass_hz / _SAMPLE_RATE
    # Reinforce each drone above its fundamental so it carries on small speakers.
    # The summed partial amplitudes leave headroom above the 18,000 PCM melody peak.
    return tuple(
        5000 * (math.sin(phase) + 0.45 * math.sin(3 * phase))
        + 4200 * (math.sin(2 * phase) + 0.45 * math.sin(4 * phase) + 0.20 * math.sin(6 * phase))
        for phase in (step * index for index in range(period))
    )


def _render(events: list[_Event], sound: PlaybackSound, *, drone: bool = False,
            low_a: int = 440) -> bytes:
    if sound not in get_args(PlaybackSound):
        raise ValueError("sound must be 'chanter', 'chanter-old', or 'simple'")
    output = BytesIO()
    tables: dict[float, tuple[float, ...]] = {}
    phase = 0.0
    previous_table = None
    total_samples = round(sum(duration for _, duration in events) * _SAMPLE_RATE)
    transition = round(0.0015 * _SAMPLE_RATE)
    drone_samples = _drone_samples(low_a) if drone else ()
    with wave.open(output, "wb") as wav:
        wav.setparams((1, 2, _SAMPLE_RATE, 0, "NONE", "not compressed"))
        elapsed = 0.0
        sample_offset = 0
        for frequency, duration in events:
            elapsed += duration
            end = round(elapsed * _SAMPLE_RATE)
            count = end - sample_offset
            if sound == "simple":
                step = math.tau * frequency / _SAMPLE_RATE
                fade = max(1, min(count // 2, round(0.002 * _SAMPLE_RATE)))
                samples = array("h", (
                    int(12_000 * min(1, index / fade, (count - 1 - index) / fade)
                        * (math.sin(step * index)
                           + 0.35 * math.sin(3 * step * index)
                           + 0.15 * math.sin(5 * step * index)))
                    for index in range(count)
                ))
            else:
                if frequency not in tables:
                    tables[frequency] = _reed_wave(frequency, bright=sound == "chanter")
                table = tables[frequency]
                step = _TABLE_SIZE * frequency / _SAMPLE_RATE
                samples = array("h")
                blend = min(transition, count)
                for index in range(count):
                    sample = _wave_sample(table, phase)
                    if previous_table is not None and previous_table is not table and index < blend:
                        old_sample = _wave_sample(previous_table, phase)
                        sample = old_sample + (sample - old_sample) * index / blend
                    position = sample_offset + index
                    envelope = min(1, position / transition, max(0, total_samples - 1 - position) / transition)
                    samples.append(int(sample * envelope))
                    phase = (phase + step) % _TABLE_SIZE
                if count:
                    previous_table = table
            if drone_samples:
                for index in range(count):
                    position = sample_offset + index
                    envelope = min(1, position / transition, (total_samples - 1 - position) / transition)
                    samples[index] += int(drone_samples[position % len(drone_samples)] * envelope)
            sample_offset = end
            if sys.byteorder == "big":
                samples.byteswap()
            wav.writeframesraw(samples.tobytes())
    return output.getvalue()


def play(tune: Tune, *, bpm: float | None, grace_ms: float | None,
         sound: PlaybackSound, drone: bool = False) -> None:
    # Windows-only speaker output. Scheduling and WAV generation are portable.
    if sys.platform != "win32":
        raise NotImplementedError("Tune.play() requires Windows")
    import winsound

    winsound.PlaySound(
        tune.to_wav(bpm=bpm, grace_ms=grace_ms, sound=sound, drone=drone),
        winsound.SND_MEMORY | winsound.SND_NODEFAULT,
    )
