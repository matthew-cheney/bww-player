"""Resolve local repeats and alternative endings in written measure order."""

from collections.abc import Callable
from dataclasses import replace
from typing import Literal

from .models import Ending, Measure, Repeat, Token

_REPEAT_START = "I!''"
_REPEAT_END = "''!I"
_ENDING_NUMBERS: dict[str, Literal[1, 2]] = {"'1": 1, "'2": 2}
_ENDING_CLOSE = {"_", "_'"}


def is_ending_marker(token: Token) -> bool:
    return token.kind == "structural_marker" and token.raw != _REPEAT_END and (
        token.raw.startswith(("'", "_")) or token.raw == "bis_'"
    )


class _Structure:
    def __init__(self, report: Callable[[Token, str, str], None]) -> None:
        self.report = report
        self.start: Token | None = None
        self.part_start = 0
        self.open_ending: tuple[Token, int] | None = None
        self.ending_is_supported = False
        self.endings: list[Ending] = []
        self.repeats: list[Repeat] = []

    def ending_marker(self, token: Token, measure: int, in_measure: bool) -> None:
        if token.raw not in _ENDING_CLOSE:
            self.ending_is_supported = False
            if self.open_ending is not None:
                previous, _ = self.open_ending
                self.report(previous, "ambiguous_ending", "Ending overlaps another ending start")
                self.report(token, "ambiguous_ending", "Ending starts before the previous ending closes")
            elif token.raw not in _ENDING_NUMBERS:
                self.report(token, "unsupported_ending", f"Unsupported ending marker {token.raw!r}")
            elif in_measure:
                self.report(token, "ambiguous_ending", "Ending starts inside a measure")
            else:
                self.ending_is_supported = True
            self.open_ending = (token, measure)
            return

        if self.open_ending is None:
            self.report(token, "unmatched_ending", "Ending close has no opening marker")
            return
        start, first = self.open_ending
        self.open_ending = None
        stop = measure + int(in_measure)
        number = _ENDING_NUMBERS.get(start.raw)
        if stop <= first:
            self.report(token, "unmatched_ending", "Ending contains no measures")
        elif self.ending_is_supported and number is not None:
            self.endings.append(Ending(number, first, stop, start, token))

    def end_part(self, stop: int, end: Token | None = None) -> None:
        if self.open_ending is not None:
            start, _ = self.open_ending
            if self.ending_is_supported:
                self.report(start, "unmatched_ending", "Ending has no close before the part boundary")
            self.open_ending = None
        start = self.start if self.start and self.start.raw == _REPEAT_START else None
        if end is not None and end.raw == _REPEAT_END:
            if stop > self.part_start:
                self.repeats.append(Repeat(self.part_start, stop, start, end))
            else:
                self.report(end, "unmatched_repeat", "Repeat end has no preceding measures in its part")
                if start is not None:
                    self.report(start, "unmatched_repeat", "Repeat start has no intervening measures")
        elif start is not None:
            self.report(start, "unmatched_repeat", "Repeat start has no end before the part boundary")
        self.start = None
        self.part_start = stop

    def finish(self, measures: tuple[Measure, ...], *, strict: bool) -> tuple[Repeat, ...]:
        repeat_index = 0
        for ending in self.endings:
            last = measures[ending.stop_measure - 1]
            if last.notes and last.notes[-1].token.span.start > ending.end.span.start:
                self.report(ending.end, "ambiguous_ending", "Ending closes inside a measure")
                continue
            while repeat_index < len(self.repeats) and (
                self.repeats[repeat_index].stop_measure < ending.start_measure
                or (self.repeats[repeat_index].stop_measure == ending.start_measure and ending.number == 1)
            ):
                repeat_index += 1
            if repeat_index < len(self.repeats):
                repeat = self.repeats[repeat_index]
                if ending.number == 1 and (
                    repeat.start_measure < ending.start_measure < repeat.stop_measure == ending.stop_measure
                ):
                    self.repeats[repeat_index] = replace(repeat, endings=(ending,))
                    continue
                next_start = (
                    self.repeats[repeat_index + 1].start_measure
                    if repeat_index + 1 < len(self.repeats) else len(measures)
                )
                if ending.number == 2 and repeat.endings and (
                    repeat.stop_measure == ending.start_measure < ending.stop_measure <= next_start
                ):
                    self.repeats[repeat_index] = replace(repeat, endings=(*repeat.endings, ending))
                    continue
            self.report(ending.start, "ambiguous_ending", "Ending does not fit a local first/second repeat")
        if strict:
            return tuple(self.repeats)
        return tuple(
            replace(repeat, endings=()) if len(repeat.endings) == 1 else repeat
            for repeat in self.repeats
        )
