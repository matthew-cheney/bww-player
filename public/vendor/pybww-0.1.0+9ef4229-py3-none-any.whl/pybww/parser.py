"""Interpret the basic score represented by BWW tokens."""

from fractions import Fraction
from typing import Literal, cast

from .embellishments import MOVEMENTS
from .models import (
    Diagnostic, Embellishment, Measure, Note, ParseError, ParseResult, ParseStatus, Part,
    SignatureChange, SourceSpan, Token, TokenizationResult, Tune,
)
from .rhythm import _Rhythm
from .structure import _Structure, is_ending_marker

_PITCHES = {pitch: pitch for pitch in ("LG", "LA", "B", "C", "D", "E", "F", "HG", "HA")}
_PITCHES.update(A="HA", G="HG", LB="B")
_DURATIONS = {"1", "2", "4", "8", "16", "32"}
_OPEN_PART = {"I!", "I!''"}
_CLOSE_PART = {"!I", "''!I"}
_SYSTEM_END = {"!t", "!!t"}
_CLOSE_MEASURE = {"!"} | _CLOSE_PART | _SYSTEM_END
_EMBELLISHMENT_BOUNDARIES = _OPEN_PART | _CLOSE_MEASURE


class _Score:
    def __init__(self) -> None:
        self.parts: list[Part] = []
        self.measures: list[Measure] = []
        self.notes: list[Note] = []
        self.staff_breaks: list[Token] = []
        self.opening_barline: Token | None = None
        self.measure_has_gap = False
        self.has_notes = False
        self.meter: tuple[int, int] | None = None
        self.measure_index = 0

    @property
    def in_measure(self) -> bool:
        return bool(self.notes or self.measure_has_gap)

    def end_measure(self, barline: Token | None = None) -> None:
        if self.in_measure:
            durations = [note.duration for note in self.notes if note.duration is not None]
            is_pickup = bool(
                self.meter and not self.measures and not self.measure_has_gap
                and len(durations) == len(self.notes)
                and sum(durations) < Fraction(*self.meter)
            )
            self.measures.append(Measure(
                tuple(self.notes), self.opening_barline, barline, is_pickup,
            ))
            self.notes.clear()
            self.measure_has_gap = False
            self.measure_index += 1
        self.opening_barline = None

    def end_part(self) -> None:
        self.end_measure()
        if self.measures:
            self.parts.append(Part(tuple(self.measures), tuple(self.staff_breaks)))
        self.measures.clear()
        self.staff_breaks.clear()


def _meter(raw: str) -> tuple[int, int] | None:
    if raw == "C":
        return (4, 4)
    if raw == "C_":
        return (2, 2)
    beats, unit = raw.split("_")
    count = _positive_int(beats)
    if count is not None and unit in _DURATIONS:
        return (count, int(unit))
    return None


def _positive_int(raw: str) -> int | None:
    try:
        return int(raw) or None
    except ValueError:
        return None


def _playback_values(raw: str, count: int, minimum: int) -> tuple[int, ...] | None:
    try:
        values = tuple(int(value) for value in raw.split("(", 1)[1][:-1].split(","))
    except ValueError:
        return None
    if len(values) == count and all(value >= minimum for value in values):
        return values
    return None


def parse_tokens(
    source: TokenizationResult, filename: str | None, strict: bool
) -> ParseResult:
    score = _Score()
    diagnostics = {item.span: item for item in source.diagnostics}
    unsupported: dict[SourceSpan, Token] = {}
    pending: list[Token] = []
    unattached: list[Embellishment] = []
    metadata: dict[str, str] = {}
    tempo = None
    frequencies = None
    grace_durations = None
    initial_meter = None
    key_signature: tuple[str, ...] | None = None
    current_meter = None
    signature_changes: list[SignatureChange] = []
    music_started = False
    tokens = source.tokens

    def report(
        token: Token, code: str = "unsupported_notation", message: str | None = None,
    ) -> None:
        unsupported[token.span] = token
        previous = diagnostics.get(token.span)
        if message is None:
            message = previous.message if previous else f"Unsupported BWW notation {token.raw!r}"
        diagnostics[token.span] = Diagnostic(
            code, "error" if strict else "warning", message, token.span,
        )

    def report_gap(
        token: Token, code: str = "unsupported_notation", message: str | None = None,
    ) -> None:
        score.measure_has_gap = True
        report(token, code, message)

    rhythm = _Rhythm(score.notes, report_gap)
    structure = _Structure(report)

    def declare_signature(
        clef: Token | None, keys: tuple[Token, ...], time: Token | None,
    ) -> None:
        nonlocal initial_meter, key_signature, current_meter
        key = tuple(item.raw for item in keys) if keys else None
        if clef is not None and key_signature is None and not score.has_notes and key is None:
            key = ()
        meter = _meter(time.raw) if time else None
        if time is not None and meter is None:
            report(time, "unsupported_signature", f"Unsupported meter {time.raw!r}")
        if not score.has_notes:
            if key is not None:
                key_signature = key
            if meter is not None:
                initial_meter = meter
        if key is not None or time is not None:
            signature_changes.append(SignatureChange(
                score.measure_index, len(score.notes),
                tuple(item for item in (clef, *keys, time) if item is not None), meter, key,
            ))
        if meter is not None:
            current_meter = meter
            if not score.in_measure:
                score.meter = meter

    def end_measure(barline: Token | None = None) -> None:
        rhythm.end_measure()
        score.end_measure(barline)
        score.meter = current_meter

    def resolve_embellishments(pitch: str | None, *, ambiguous: bool = False) -> tuple[Embellishment, ...]:
        attached = []
        for prefix in pending:
            movement = MOVEMENTS[prefix.raw]
            ornament = Embellishment(
                prefix.raw, prefix.span, movement.name, movement.category, movement.pitches,
            )
            if pitch is not None and movement.target in (None, pitch):
                attached.append(ornament)
                continue
            unattached.append(ornament)
            if pitch is not None:
                report_gap(
                    prefix, "ambiguous_embellishment",
                    f"Expected {movement.target} after {prefix.raw!r}, found {pitch}",
                )
            elif ambiguous:
                report_gap(prefix, "ambiguous_embellishment", f"Cannot identify the melody note for {prefix.raw!r}")
            else:
                report_gap(prefix, "orphaned_embellishment", f"No following melody note for {prefix.raw!r}")
        pending.clear()
        return tuple(attached)

    index = 0
    while index < len(tokens):
        token = tokens[index]
        index += 1
        raw = token.raw
        ending_marker = is_ending_marker(token)
        if token.kind == "embellishment" and raw in MOVEMENTS:
            music_started = True
            rhythm.postfix_allowed = False
            pending.append(token)
            continue
        if token.kind == "note":
            stem, denominator = raw.split("_")
            pitch = _PITCHES.get(stem.rstrip("rl"))
            if pitch is not None and denominator in _DURATIONS:
                music_started = True
                beam = cast(Literal["r", "l"], stem[-1]) if stem[-1] in "rl" else None
                rhythm.add_note(Note(
                    pitch, Fraction(1, int(denominator)), token, beam, resolve_embellishments(pitch),
                ))
                score.has_notes = True
                continue
        if token.kind == "rhythmic_marker" or (
            token.kind == "unknown" and raw.startswith(("'", "^", "fermat")) and "!" not in raw
        ):
            music_started = True
            if pending and not (raw.startswith("^") and raw.endswith("s")):
                resolve_embellishments(None, ambiguous=True)
            rhythm.marker(token)
            continue
        if pending and token.kind != "accidental" and not ending_marker:
            boundary = (
                token.kind in ("rest", "clef", "time_signature")
                or raw in _EMBELLISHMENT_BOUNDARIES
            )
            resolve_embellishments(None, ambiguous=not boundary)
        if token.kind == "metadata":
            if not music_started:
                value, fields = raw[1:].split('"', 1)
                tag = fields.split("(", 1)[1].split(",", 1)[0].rstrip(")").strip()
                if value:
                    metadata.setdefault(tag, value)
            continue
        if token.kind == "header":
            if raw.startswith("TuneTempo"):
                bpm = _positive_int(raw.split(",")[1])
                if music_started or bpm is None:
                    report_gap(token)
                else:
                    tempo = bpm
            elif not music_started and raw.startswith("FrequencyMappings"):
                frequencies = _playback_values(raw, 27, 1) or frequencies
            elif not music_started and raw.startswith("GracenoteDurations"):
                grace_durations = _playback_values(raw, 13, 0) or grace_durations
            continue
        lexical = diagnostics.get(token.span)
        if lexical and lexical.code == "malformed_metadata" and not music_started:
            continue
        if token.kind in ("clef", "time_signature"):
            rhythm.postfix_allowed = False
            rhythm.end_beam()
            clef = token if token.kind == "clef" else None
            music_started = True
            key_tokens = []
            signature = token if clef is None else None
            if clef is not None:
                if (score.in_measure or score.measures) and tokens[index - 2].raw not in _SYSTEM_END:
                    score.staff_breaks.append(clef)
                while index < len(tokens) and tokens[index].kind == "accidental":
                    key_tokens.append(tokens[index])
                    index += 1
                if index < len(tokens) and tokens[index].kind == "time_signature":
                    signature = tokens[index]
                    index += 1
            declare_signature(clef, tuple(key_tokens), signature)
            continue
        music_started = True
        if ending_marker:
            rhythm.postfix_allowed = False
            structure.ending_marker(token, score.measure_index, score.in_measure)
        elif raw in _OPEN_PART:
            end_measure()
            structure.end_part(score.measure_index)
            score.end_part()
            structure.start = token
            score.opening_barline = token
        elif raw in _CLOSE_MEASURE:
            end_measure(token)
            if raw in _SYSTEM_END:
                score.staff_breaks.append(token)
            elif raw in _CLOSE_PART:
                structure.end_part(score.measure_index, token)
                score.end_part()
        elif lexical and lexical.code == "malformed_metadata":
            rhythm.interrupt()
            unsupported[token.span] = token
            score.measure_has_gap = True
        else:
            if token.kind not in ("accidental", "embellishment"):
                rhythm.interrupt()
            rhythm.postfix_allowed = False
            if token.kind == "embellishment":
                unattached.append(Embellishment(raw, token.span))
            report_gap(token)

    resolve_embellishments(None)
    rhythm.end_tie()
    end_measure()
    structure.end_part(score.measure_index)
    score.end_part()
    repeats = structure.finish(
        tuple(measure for part in score.parts for measure in part.measures),
        strict=strict,
    )
    tune = None
    if score.has_notes:
        tune = Tune(
            source_text=source.source_text, title=metadata.get("T"),
            composer=metadata.get("M"), tune_type=metadata.get("Y"), tempo=tempo,
            meter=initial_meter, key_signature=key_signature, parts=tuple(score.parts),
            ties=tuple(rhythm.ties), repeats=repeats, signature_changes=tuple(signature_changes),
            frequency_mappings=frequencies, gracenote_durations=grace_durations,
            is_partial=bool(unsupported),
        )
        status: ParseStatus = "partial" if unsupported else "complete"
    else:
        span = SourceSpan(1, 1, 0, 0, filename)
        diagnostics[span] = Diagnostic("no_music", "error", "No supported notes found", span)
        status = "failed"

    reports = tuple(sorted(diagnostics.values(), key=lambda item: item.span.start))
    if strict and any(item.severity == "error" for item in reports):
        raise ParseError(reports)
    return ParseResult(
        tune, reports, status, source.source_text, tokens,
        tuple(sorted(unsupported.values(), key=lambda item: item.span.start)), tuple(unattached),
    )
