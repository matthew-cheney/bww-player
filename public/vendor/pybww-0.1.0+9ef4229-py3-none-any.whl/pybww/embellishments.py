"""Interpret selected Bagpipe Reader grace-note codes. See README for sources."""

from typing import NamedTuple

from .models import Embellishment, EmbellishmentCategory


def grace_notes_before_beat(embellishment: Embellishment) -> int:
    """Return how many grace notes borrow time from the preceding melody note."""
    pitches = embellishment.grace_pitches or ()
    if embellishment.category == "taorluath" or embellishment.code in ("grp", "grpb", "hgrp"):
        # Standalone grips and taorluaths finish on the beat.
        return len(pitches)
    # Full throws and bubbly notes lead into the beat with low G.
    if embellishment.category in ("throw", "bubbly_note") and pitches[:1] == ("LG",):
        return 1
    return 0


class _Movement(NamedTuple):
    name: str
    category: EmbellishmentCategory
    pitches: tuple[str, ...]
    target: str | None = None


MOVEMENTS = {
    code: _Movement(f"{pitch} grace note", "grace_note", (pitch,))
    for code, pitch in zip(
        ("ag", "bg", "cg", "dg", "eg", "fg", "gg", "tg"),
        ("LA", "B", "C", "D", "E", "F", "HG", "HA"),
        strict=True,
    )
}
MOVEMENTS.update({
    "dbla": _Movement("LA doubling", "doubling", ("HG", "LA", "D"), "LA"),
    "dbb": _Movement("B doubling", "doubling", ("HG", "B", "D"), "B"),
    "dbc": _Movement("C doubling", "doubling", ("HG", "C", "D"), "C"),
    "dbd": _Movement("D doubling", "doubling", ("HG", "D", "E"), "D"),
    "dbe": _Movement("E doubling", "doubling", ("HG", "E", "F"), "E"),
    "dbf": _Movement("F doubling", "doubling", ("HG", "F", "HG"), "F"),
    "dblg": _Movement("LG doubling", "doubling", ("HG", "LG", "D"), "LG"),
    "dbhg": _Movement("HG doubling", "doubling", ("HG", "F"), "HG"),
    "dbha": _Movement("HA doubling", "doubling", ("HA", "HG"), "HA"),
    "grp": _Movement("grip", "grip", ("LG", "D", "LG")),
    "hgrp": _Movement("half grip", "grip", ("D", "LG")),
    "grpb": _Movement("B-grace grip", "grip", ("LG", "B", "LG")),
    "tar": _Movement("taorluath", "taorluath", ("LG", "D", "LG", "E")),
    "tarb": _Movement("B-grace taorluath", "taorluath", ("LG", "B", "LG", "E")),
    "htar": _Movement("half taorluath", "taorluath", ("D", "LG", "E")),
    "thrd": _Movement("light D throw", "throw", ("LG", "D", "C"), "D"),
    "hvthrd": _Movement("heavy D throw", "throw", ("LG", "D", "LG", "C"), "D"),
    "hthrd": _Movement("half light D throw", "throw", ("D", "C"), "D"),
    "hhvthrd": _Movement("half heavy D throw", "throw", ("D", "LG", "C"), "D"),
    "chedare": _Movement("chedare", "throw", ("F", "E", "HG", "E"), "F"),
    "bubly": _Movement("bubbly note", "bubbly_note", ("LG", "E", "LG", "C", "LG")),
    "hbubly": _Movement("half bubbly note", "bubbly_note", ("D", "LG", "C", "LG")),
    "brl": _Movement("birl", "birl", ("LG", "LA", "LG"), "LA"),
    "abr": _Movement("A-grace birl", "birl", ("LA", "LG", "LA", "LG"), "LA"),
    "gbr": _Movement("G-grace birl", "birl", ("HG", "LA", "LG", "LA", "LG"), "LA"),
    "tbr": _Movement("thumb birl", "birl", ("HA", "LA", "LG", "LA", "LG"), "LA"),
})


MOVEMENTS["chedari"] = MOVEMENTS["chedare"]


def _doubling_variants() -> dict[str, _Movement]:
    movements = {}
    for target in ("LG", "LA", "B", "C", "D", "E", "F"):
        code = "db" + target.lower()
        tail = MOVEMENTS[code].pitches[1:]
        movements["t" + code] = _Movement(
            f"{target} thumb doubling", "doubling", ("HA",) + tail, target,
        )
        movements["h" + code] = _Movement(f"{target} half doubling", "doubling", tail, target)
    return movements


def _compound_grips() -> dict[str, _Movement]:
    movements = {}
    for prefix, style, opening, targets in (
        ("g", "G-grace", ("HG",), ("LA", "B", "C", "D", "E", "F")),
        ("t", "thumb", ("HA",), ("LA", "B", "C", "D", "E", "F", "HG")),
        ("h", "half", (), ("LA", "B", "C", "D", "E", "F", "HG", "HA")),
    ):
        for target in targets:
            middle = "F" if target == "F" or (prefix == "t" and target == "HG") else "D"
            movements[prefix + "grp" + target.lower()] = _Movement(
                f"{target} {style} grip", "grip", opening + (target, "LG", middle, "LG"), target,
            )
        movements[prefix + "grpdb"] = _Movement(
            f"D {style} B-grace grip", "grip", opening + ("D", "LG", "B", "LG"), "D",
        )
    return movements


def _peles() -> dict[str, _Movement]:
    movements = {}
    for prefix, style, opening in (("", "", ("HG",)), ("t", "thumb ", ("HA",)), ("h", "half ", ())):
        for target, lift, cut in (
            ("LA", "E", "LG"), ("B", "E", "LG"), ("C", "E", "LG"),
            ("D", "E", "LG"), ("E", "F", "LA"), ("F", "HG", "E"), ("HG", "HA", "F"),
        ):
            if not prefix and target == "HG":
                continue
            code = prefix + "pel" + target.lower()
            pitches = opening + (target, lift, target, cut)
            movements[code] = _Movement(f"{target} {style}pelé", "pele", pitches, target)
            if target == "D":
                movements["l" + code] = _Movement(
                    f"D light {style}pelé", "pele", pitches[:-1] + ("C",), target,
                )
    return movements


MOVEMENTS.update(_doubling_variants())
MOVEMENTS.update(_compound_grips())
MOVEMENTS.update(_peles())
MOVEMENTS.update({
    first_code + second.lower(): _Movement(
        f"{first}–{second} double grace note", "grace_note", (first, second),
    )
    for first_code, first, lower_pitches in (
        ("d", "D", ("LG", "LA", "B", "C")),
        ("e", "E", ("LG", "LA", "B", "C", "D")),
        ("f", "F", ("LG", "LA", "B", "C", "D", "E")),
        ("g", "HG", ("LG", "LA", "B", "C", "D", "E", "F")),
        ("t", "HA", ("LG", "LA", "B", "C", "D", "E", "F", "HG")),
    )
    for second in lower_pitches
})


# For compound strikes the suffix names the melody note. The cut alternates
# with that note. A g or t prefix adds an opening high G or thumb grace note.
_STRIKE_CUTS = {
    "LA": "LG", "B": "LG", "C": "LG", "D": "LG",
    "E": "LA", "F": "E", "HG": "F", "HA": "HG",
}


def _compound_strikes() -> dict[str, _Movement]:
    movements = {}
    for count, size in ((1, "single"), (2, "double"), (3, "triple")):
        for prefix, style, opening, targets in (
            ("", "", (), tuple(_STRIKE_CUTS)),
            ("g", "G-grace ", ("HG",), ("LA", "B", "C", "D", "E", "F")),
            ("t", "thumb ", ("HA",), ("LA", "B", "C", "D", "E", "F", "HG")),
            ("h", "half ", (), tuple(_STRIKE_CUTS)),
        ):
            if count == 1:
                if not prefix:
                    continue
                targets = tuple(target for target in targets if target != "HA")
            stem = f"{prefix}st" + (str(count) if count > 1 else "")
            for target in targets:
                cut = _STRIKE_CUTS[target]
                if prefix == "h" and target == "F" and count > 1:
                    cut = "D"
                # Regular doubles/triples open with the cut. Other forms
                # include the melody pitch after any opening grace note.
                pitches = (cut, target) * count
                pitches = opening + ((target,) + pitches[:-1] if prefix else pitches[:-1])
                movements[stem + target.lower()] = _Movement(
                    f"{target} {style}{size} strike", "strike", pitches, target,
                )
            # The light D variants cut to C. The single G and half forms
            # have their own lead-in pitches.
            light = movements[stem + "d"]
            pitches = tuple("C" if pitch == "LG" else pitch for pitch in light.pitches)
            if count == 1:
                pitches = {"g": ("HG", "E", "C"), "t": pitches, "h": ("E", "D")}[prefix]
            movements["l" + stem + "d"] = light._replace(
                name=f"D light {style}{size} strike", pitches=pitches,
            )
    return movements


# The str suffix names the grace pitch and can precede different melody notes.
MOVEMENTS.update({
    f"str{pitch.lower()}": _Movement(f"{pitch} strike", "strike", (pitch,))
    for pitch in ("LG", "LA", "B", "C", "D", "E", "F", "HG")
})
MOVEMENTS.update(_compound_strikes())
