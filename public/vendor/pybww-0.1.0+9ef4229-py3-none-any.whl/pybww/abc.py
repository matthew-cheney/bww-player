"""Export the interpreted score as ABC 2.1."""

from bisect import bisect_left
from dataclasses import dataclass
from fractions import Fraction

from .models import Measure, Note, Tune
from .serialization import written_measures

_PITCH = dict(zip(
    ("LG", "LA", "B", "C", "D", "E", "F", "HG", "HA"),
    "GABcdefga", strict=True,
))
_KEY_PITCH = {**{pitch.lower(): abc for pitch, abc in _PITCH.items()}, "g": "g", "a": "a"}
_KEY_ACCIDENTAL = {"sharp": "^", "flat": "_", "natural": "="}
_PIPE_KEY = {"^f", "^c"}
_COMPOUND_METERS = {(6, 8), (9, 8), (12, 8)}


def _text(value: str) -> str:
    return " ".join(value.splitlines()).replace("\\", "\\\\").replace("%", r"\%")


def _key(signature: tuple[str, ...] | None) -> str:
    if not signature:
        return "none"
    accidentals = [
        abc + _KEY_PITCH[accidental[len(prefix):]]
        for accidental in signature
        for prefix, abc in _KEY_ACCIDENTAL.items()
        if accidental.startswith(prefix)
    ]
    if set(accidentals) in (_PIPE_KEY, _PIPE_KEY | {"=g"}):
        return "Hp"
    return "C exp " + " ".join(accidentals)


def _meter(meter: tuple[int, int] | None) -> str:
    return f"{meter[0]}/{meter[1]}" if meter else "none"


def _beat(meter: tuple[int, int] | None) -> str:
    return "3/8" if meter in _COMPOUND_METERS else "1/4"


def _note(note: Note) -> str:
    length = note.duration if note.duration is not None else note.base_duration
    if note.tuplet is not None and note.duration is not None:
        length *= Fraction(note.tuplet.actual, note.tuplet.normal)
    units = length * 8  # L:1/8
    suffix = str(units) if units != 1 else ""
    graces = "".join(
        _PITCH[pitch] for movement in note.embellishments for pitch in movement.grace_pitches or ()
    )
    return (f"{{{graces}}}" if graces else "") + _PITCH[note.pitch] + suffix


@dataclass(frozen=True, slots=True)
class AbcSerializer:
    """Callable serializer for a single written tune."""

    allow_partial: bool = False

    def __call__(self, tune: Tune, /) -> str:
        if tune.is_partial and not self.allow_partial:
            raise ValueError("Cannot export a partial tune to ABC unless allow_partial=True")
        if not any(measure.notes for _, _, measure in written_measures(tune)):
            raise ValueError("Cannot export a tune without notes to ABC")

        header = ["%abc-2.1", "X:1", "T:" + _text(tune.title or "Untitled")]
        if tune.composer:
            header.append("C:" + _text(tune.composer))
        if tune.tune_type:
            header.append("R:" + _text(tune.tune_type))
        header.extend((f"M:{_meter(tune.meter)}", "L:1/8"))
        if tune.tempo is not None:
            header.append(f"Q:{_beat(tune.meter)}={tune.tempo}")
        header.append(f"K:{_key(tune.key_signature)}")
        return "\n".join((*header, _body(tune), ""))


def _barline(previous: Measure | None, current: Measure | None, *,
             starts_repeat: bool, stops_repeat: bool, stops_ending: bool) -> str:
    if stops_repeat:
        return "::" if starts_repeat else ":|"
    if starts_repeat:
        return "|:"
    if current is None:
        return "|]"
    if previous is None:
        return "[|" if current.opening_barline else ""
    closing = previous.closing_barline
    if stops_ending or current.opening_barline or (closing and closing.raw in ("!I", "!!t")):
        return "||"
    return "|"


def _signature_fields(tune: Tune) -> dict[tuple[int, int], str]:
    declarations: dict[tuple[int, int], dict[str, str]] = {}
    for change in tune.signature_changes:
        position = (change.measure_index, change.note_index)
        # The header already reflects declarations before the first note.
        if position == (0, 0):
            continue
        fields = declarations.setdefault(position, {})
        if change.meter is not None:
            fields["M"] = _meter(change.meter)
            if tune.tempo is not None:
                fields["Q"] = f"{_beat(change.meter)}={tune.tempo}"
        if change.key_signature is not None:
            fields["K"] = _key(change.key_signature)

    active = {"M": _meter(tune.meter), "K": _key(tune.key_signature)}
    if tune.tempo is not None:
        active["Q"] = f"{_beat(tune.meter)}={tune.tempo}"
    result = {}
    for position, fields in sorted(declarations.items()):
        result[position] = "".join(
            f"[{name}:{value}]" for name, value in fields.items() if active.get(name) != value
        )
        active.update(fields)
    return result


def _body(tune: Tune) -> str:
    signatures = _signature_fields(tune)
    starts = {repeat.start_measure for repeat in tune.repeats}
    stops = {repeat.stop_measure for repeat in tune.repeats}
    endings = {ending.start_measure: ending.number
               for repeat in tune.repeats for ending in repeat.endings}
    ending_stops = {ending.stop_measure for repeat in tune.repeats for ending in repeat.endings}
    tied = {tie.source for tie in tune.ties}

    pieces = []
    previous_measure = previous_part = None
    previous_note = None
    breaks: list[int] = []
    count = 0
    for index, part, measure in written_measures(tune):
        part_changed = part is not previous_part
        if part_changed:
            breaks = sorted(token.span.start for token in part.staff_breaks)
        bar = _barline(previous_measure, measure, starts_repeat=index in starts,
                       stops_repeat=index in stops, stops_ending=index in ending_stops)
        if index in endings:
            bar += str(endings[index])
        if bar:
            pieces.append(f" {bar} " if pieces else f"{bar} ")
        if part_changed and previous_part is not None:
            pieces.append("\n")

        beam = tuplet = None
        for note_index, note in enumerate(measure.notes):
            if previous_note is not None and (not part_changed or note_index):
                start = previous_note.token.span.end
                end = note.token.span.start
                if bisect_left(breaks, start) < bisect_left(breaks, end):
                    pieces.append("\n")
                    beam = None
            fields = signatures.get((index, note_index))
            if fields:
                pieces.append(fields)
                beam = None
            if note_index and (beam is None or beam != note.beam_group):
                pieces.append(" ")
            if note.tuplet is not None and note.tuplet != tuplet:
                actual, normal = note.tuplet.actual, note.tuplet.normal
                pieces.append(f"({actual}:{normal}:{actual}")
            pieces.append(_note(note))
            if note.token in tied:
                pieces.append("-")
            beam, tuplet, previous_note = note.beam_group, note.tuplet, note

        pieces.append(signatures.get((index, len(measure.notes)), ""))
        previous_measure, previous_part = measure, part
        count = index + 1

    pieces.append(" " + _barline(previous_measure, None, starts_repeat=False,
                                stops_repeat=count in stops, stops_ending=count in ending_stops))
    return "\n".join(line.strip() for line in "".join(pieces).splitlines() if line.strip())
