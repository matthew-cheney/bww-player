"""Command-line playback and export for BWW files."""

import argparse
import sys
from pathlib import Path
from typing import get_args

from .api import parse_file
from .audio import PlaybackSound, render_wav


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(
        prog="pybww", description="Play a BWW tune on Windows or export it as ABC notation."
    )
    parser.add_argument("file", type=Path, help="path to a BWW file")
    parser.add_argument("--encoding", default="utf-8", help="file encoding (default: utf-8)")
    export = parser.add_argument_group("export options")
    export.add_argument("--abc", action="store_true", help="write ABC notation to standard output")
    export.add_argument(
        "--allow-partial", action="store_true",
        help="export the interpreted score even if some notation is unsupported (requires --abc)",
    )
    playback = parser.add_argument_group("playback options", argument_default=argparse.SUPPRESS)
    playback.add_argument(
        "--bpm", type=float,
        help="beats per minute (dotted-quarter beats in 6/8, 9/8, and 12/8; default: written tempo or 90)",
    )
    playback.add_argument(
        "--grace-ms", type=float, help="override grace-note timing in ms (file values or 25 by default; 0 disables)"
    )
    playback.add_argument(
        "--sound", choices=get_args(PlaybackSound), help="synthesized sound (default: chanter)"
    )
    playback.add_argument("--drone", action="store_true", help="add bass and tenor drones")
    options = vars(parser.parse_args(argv))
    path = options.pop("file")
    encoding = options.pop("encoding")
    abc = options.pop("abc")
    allow_partial = options.pop("allow_partial")
    if allow_partial and not abc:
        parser.error("--allow-partial requires --abc")
    if abc and options:
        parser.error("--abc cannot be combined with playback options")

    try:
        result = parse_file(path, encoding=encoding)
        for diagnostic in result.diagnostics:
            span = diagnostic.span
            print(
                f"{path}:{span.line}:{span.column}: {diagnostic.severity}: {diagnostic.message}",
                file=sys.stderr,
            )
        if result.tune is None:
            raise ValueError("no exportable tune found" if abc else "no playable tune found")
        if abc:
            sys.stdout.write(result.tune.to_abc(allow_partial=allow_partial))
        else:
            if sys.platform != "win32":
                raise NotImplementedError("speaker playback requires Windows")
            import winsound

            wav, _ = render_wav(result.tune, **options)
            winsound.PlaySound(wav, winsound.SND_MEMORY | winsound.SND_NODEFAULT)
    except (OSError, ValueError, LookupError, RuntimeError) as error:
        print(f"{parser.prog}: {path}: {error}", file=sys.stderr)
        return 1
    return 0
