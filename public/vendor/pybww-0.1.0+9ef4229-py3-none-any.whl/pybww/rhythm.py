"""Interpret rhythmic markers while assembling written notes."""

import re
from collections.abc import Callable
from dataclasses import replace
from fractions import Fraction

from .models import Note, Tie, Token, Tuplet

_DOT = re.compile(r"('{1,2})([a-g]|[hl][ag])")
_TUPLET = re.compile(r"\^([0-9])([0-9]?)([se])")
_TUPLET_RATIOS = {
    "2": (2, 3), "3": (3, 2), "43": (4, 3), "46": (4, 6),
    "53": (5, 3), "54": (5, 4), "64": (6, 4), "74": (7, 4), "76": (7, 6),
}
_DOT_PITCHES = {"A": "HA", "G": "HG"}


class _Rhythm:
    def __init__(self, notes: list[Note], report: Callable[[Token, str, str], None]) -> None:
        self.notes = notes
        self.report = report
        self.tuplets: list[tuple[Token, int]] = []
        self.tuplet_interrupted = False
        self.beam_start: int | None = None
        self.beam_closed = False
        self.tie_start: Token | None = None
        self.tie_notes: list[Note] = []
        self.ties: list[Tie] = []
        self.postfix_allowed = False
        self.tuplet_floor = 0

    def add_note(self, note: Note) -> None:
        # BWW also writes groups like r l l, with all later flags facing left.
        if note.beam is None or (note.beam == "r" and self.beam_closed):
            self.end_beam()
        if note.beam is not None:
            if note.base_duration > Fraction(1, 8):
                self.end_beam()
                self.report(note.token, "malformed_beam", "Beam flags require an eighth note or shorter")
            elif note.beam == "r" and self.beam_start is None:
                self.beam_start = len(self.notes)
            elif note.beam == "l":
                if self.beam_start is None:
                    self.report(note.token, "malformed_beam", "Left beam flag has no opening right flag")
                else:
                    self.beam_closed = True
        if self.tie_start is not None:
            self.tie_notes.append(note)
            if len(self.tie_notes) > 2:
                self.end_tie()
        self.notes.append(note)
        self.postfix_allowed = True

    def end_beam(self) -> None:
        if self.beam_start is None:
            return
        start = self.beam_start
        opening = self.notes[start].token
        if self.beam_closed:
            for index in range(start, len(self.notes)):
                self.notes[index] = replace(self.notes[index], beam_group=opening.span)
        else:
            self.report(opening, "incomplete_beam", "Beam group has no left flag")
        self.beam_start = None
        self.beam_closed = False

    def end_tie(self, end: Token | None = None) -> None:
        start = self.tie_start
        if start is not None:
            if end is None:
                self.report(start, "incomplete_tie", "Tie start has no matching end around two notes")
            elif len(self.tie_notes) != 2 or self.tie_notes[0].pitch != self.tie_notes[1].pitch:
                self.report(end, "malformed_tie", "A tie must enclose two consecutive notes of the same pitch")
            else:
                first, second = self.tie_notes
                self.ties.append(Tie(first.token, second.token, start, end))
        elif end is not None:
            self.report(end, "malformed_tie", "Tie end has no matching start")
        self.tie_start = None
        self.tie_notes.clear()

    def interrupt(self) -> None:
        """A rest or unresolved musical token interrupts written adjacency."""
        self.postfix_allowed = False
        self.tuplet_floor = len(self.notes)
        self.tuplet_interrupted |= bool(self.tuplets)
        self.end_beam()
        self.end_tie()

    def end_measure(self) -> None:
        self.postfix_allowed = False
        self.end_beam()
        if self.tuplets:
            start, first = self.tuplets[0]
            self.report(start, "incomplete_tuplet", "Tuplet has no matching end within the measure")
            for index in range(first, len(self.notes)):
                self._adjust(index, tuple(token for token, _ in self.tuplets))
        self.tuplets.clear()
        self.tuplet_interrupted = False
        self.tuplet_floor = 0

    def _adjust(self, index: int, markers: tuple[Token, ...], tuplet: Tuplet | None = None) -> None:
        note = self.notes[index]
        duration = note.duration
        if duration is not None and tuplet is not None:
            duration *= Fraction(tuplet.normal, tuplet.actual)
        else:
            duration = None
        self.notes[index] = replace(
            note, duration=duration, tuplet=tuplet or note.tuplet,
            duration_markers=tuple(sorted((*note.duration_markers, *markers), key=lambda token: token.span.start)),
        )

    def marker(self, token: Token) -> None:
        raw = token.raw
        if raw.startswith(("'", "fermat")):
            self._postfix(token)
            return
        self.postfix_allowed = False
        if raw == "^ts":
            self.end_tie()
            self.tie_start = token
        elif raw == "^te":
            self.end_tie(token)
        elif raw.startswith("^t"):
            self.end_tie()
            self.report(token, "unsupported_rhythm", f"Unsupported tie marker {raw!r}")
        else:
            self._tuplet_marker(token)

    def _postfix(self, token: Token) -> None:
        raw = token.raw
        if not self.postfix_allowed:
            self.report(token, "orphaned_rhythm", f"No preceding melody note for {raw!r}")
            return
        note = self.notes[-1]
        dot = _DOT.fullmatch(raw)
        pitch = dot[2].upper() if dot else ""
        if dot and _DOT_PITCHES.get(pitch, pitch) == note.pitch and not note.dot_count:
            count = len(dot[1])
            duration = note.duration
            if duration is not None:
                duration *= Fraction(3, 2) if count == 1 else Fraction(7, 4)
            self.notes[-1] = replace(
                note, duration=duration, dot_count=count,
                duration_markers=(*note.duration_markers, token),
            )
        else:
            code = "unsupported_rhythm" if raw.startswith("fermat") else "malformed_dot"
            self.report(token, code, f"Cannot determine the duration after {raw!r} on {note.pitch}")
            self._adjust(-1, (token,))

    def _tuplet_marker(self, token: Token) -> None:
        raw = token.raw
        match = _TUPLET.fullmatch(raw)
        ratio = _TUPLET_RATIOS.get(match[1] + match[2]) if match else None
        if raw.endswith("s"):
            if self.tuplets or ratio is None:
                self.tuplet_interrupted = True
                self.report(token, "unsupported_tuplet", f"Unsupported tuplet start {raw!r}")
            self.tuplets.append((token, len(self.notes)))
            return

        if not self.tuplets:
            self.report(token, "orphaned_tuplet", f"No matching tuplet start for {raw!r}")
            # An unmatched ending may still describe the immediately preceding notes.
            count = int(match[1]) if match else 3
            for index in range(max(self.tuplet_floor, len(self.notes) - count), len(self.notes)):
                self._adjust(index, (token,))
        else:
            start, first = self.tuplets.pop()
            tuplet = None
            if ratio and raw[:-1] == start.raw[:-1] and len(self.notes) - first == ratio[0]:
                if not self.tuplet_interrupted:
                    tuplet = Tuplet(*ratio, start, token)
            if tuplet is None:
                self.report(token, "malformed_tuplet", f"Cannot resolve tuplet {start.raw!r} to {raw!r}")
                self.tuplet_interrupted = True
            for index in range(first, len(self.notes)):
                self._adjust(index, (start, token), tuplet)
            if not self.tuplets:
                self.tuplet_interrupted = False
        self.tuplet_floor = len(self.notes)
