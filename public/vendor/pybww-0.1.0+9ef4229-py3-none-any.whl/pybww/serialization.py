"""Shared interface and written-score traversal for exporters."""

from collections.abc import Iterator

from .models import Measure, Part, Tune, TuneSerializer as TuneSerializer


def written_measures(tune: Tune) -> Iterator[tuple[int, Part, Measure]]:
    """Yield measures with the global indices used by repeats and signatures."""
    measures = ((part, measure) for part in tune.parts for measure in part.measures)
    for index, (part, measure) in enumerate(measures):
        yield index, part, measure
