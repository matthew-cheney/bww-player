"""Run the pybww command with python -m pybww."""

from .cli import main

if __name__ == "__main__":
    raise SystemExit(main())
