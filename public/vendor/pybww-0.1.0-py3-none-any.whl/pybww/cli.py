"""Command-line playback for BWW files."""

import argparse
import sys
from pathlib import Path
from typing import get_args

from .api import parse_file
from .models import PlaybackSound


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(
        prog="pybww", description="Play a BWW tune through the default Windows audio device."
    )
    parser.add_argument("file", type=Path, help="path to a BWW file")
    parser.add_argument("--encoding", default="utf-8", help="file encoding (default: utf-8)")
    playback = parser.add_argument_group("playback options", argument_default=argparse.SUPPRESS)
    playback.add_argument(
        "--bpm", type=float,
        help="beats per minute (dotted-quarter beats in 6/8, 9/8, and 12/8; default: written tempo or 90)",
    )
    playback.add_argument(
        "--grace-ms", type=float, help="milliseconds per grace note (default: 25, 0 disables)"
    )
    playback.add_argument(
        "--sound", choices=get_args(PlaybackSound), help="synthesized sound (default: chanter)"
    )
    playback.add_argument("--drone", action="store_true", help="add bass and tenor drones")
    options = vars(parser.parse_args(argv))
    path = options.pop("file")
    encoding = options.pop("encoding")

    try:
        result = parse_file(path, encoding=encoding)
        for diagnostic in result.diagnostics:
            span = diagnostic.span
            print(
                f"{path}:{span.line}:{span.column}: {diagnostic.severity}: {diagnostic.message}",
                file=sys.stderr,
            )
        if result.tune is None:
            raise ValueError("no playable tune found")
        result.tune.play(**options)
    except (OSError, ValueError, LookupError, RuntimeError) as error:
        print(f"{parser.prog}: {path}: {error}", file=sys.stderr)
        return 1
    return 0
