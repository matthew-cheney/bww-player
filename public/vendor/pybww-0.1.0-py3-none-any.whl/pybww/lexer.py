"""Lexical recognition of BWW records and music symbols."""

import re
from typing import cast

from .models import Diagnostic, SourceSpan, Token, TokenKind, TokenizationResult

_LINE_END_OR_EOF = re.compile(r"\r\n|\r|\n|\Z")
_TOKEN = re.compile(
    r'(?P<metadata>"[^"]*"\s*,\s*\([^()]*\))(?=\s|$)'
    r'|(?P<malformed_metadata>".*)'
    r"|(?P<header>Bagpipe (?:Reader|Music Writer(?: Gold)?):[0-9]+(?:\.[0-9]+)*"
    r"|(?:MIDINoteMappings|FrequencyMappings|InstrumentMappings|GracenoteDurations"
    r"|FontSizes|TuneFormat)\s*,\s*\([^()]*\)|TuneTempo\s*,\s*[0-9]+)(?=\s|$)"
    r"|(?P<symbol>\S+)"
)

_SYMBOLS: dict[TokenKind, re.Pattern[str]] = {
    "clef": re.compile(r"&"),
    "accidental": re.compile(r"(?:sharp|flat|natural)(?:[a-g]|[hl][ag])"),
    "time_signature": re.compile(r"C_?|[0-9]+_[0-9]+"),
    "note": re.compile(r"[HL]?[A-G][rl]?_[0-9]+"),
    "rest": re.compile(r"REST_[0-9]+"),
    "embellishment": re.compile(
        r"[a-gt]g|(?:[th]?db)(?:[hl][ag]|[b-f])"
        r"|[de]l[ga]|d[bc]|e[b-d]|[fg]l[ga]|f[b-e]|g[b-f]|t(?:l[ga]|[b-f]|hg)"
        r"|(?:str|[gth]st|[gth]?st[23]|echo)(?:[hl][ag]|[b-f])"
        r"|l(?:[gth]st[23]?|st[23])d"
        r"|grp|hgrp|grpb|[gth]grp(?:la|[b-f]|db|h[ag])"
        r"|tarb?|htar|h?bubly|brl|[agt]br|(?:h?v|h|hhv)?thrd"
        r"|[th]?pel(?:la|[b-f]|hg)|l[th]?peld|f?cad(?:g|a)?(?:ed?|f)"
        r"|embari|endari|chedar[ei]|dili|h?tra|tra8|deda|h?darodo|darodo16|hiharin|rodin"
        r"|pembari|pendari|pechedari|pehedari|pdili|p(?:h?tra|tra8|grp)"
        r"|pdarodo(?:16)?|phdarodo|phiharin"
    ),
    "rhythmic_marker": re.compile(
        r"'{1,2}(?:[hl][ag]|[a-hl])|\^(?:[2-7]|43|46|53|54|64|74|76|t)[se]"
        r"|fermat(?:[a-g]|[hl][ag])?"
    ),
    "structural_marker": re.compile(
        r"!|!t|!!t|!I|I!|I!''|''!I|'(?:[0-9]+|intro|si|do|bis)|_'?|bis_'"
        r"|fine|dacapoalfine|coda|dacapoalcoda|codasection"
    ),
}


def tokenize_text(text: str, *, filename: str | None = None) -> TokenizationResult:
    """Recognize tokens in decoded text while preserving their source locations."""
    tokens: list[Token] = []
    diagnostics: list[Diagnostic] = []
    line_start = 0
    line_number = 1
    # Include an EOF match so the same loop also handles the final line.
    for ending in _LINE_END_OR_EOF.finditer(text):
        line = text[line_start:ending.start()]
        for match in _TOKEN.finditer(line):
            raw = match[0]
            span = SourceSpan(
                line_number, match.start() + 1,
                line_start + match.start(), line_start + match.end(), filename,
            )
            if match.lastgroup == "malformed_metadata":
                kind: TokenKind = "unknown"
                diagnostics.append(Diagnostic(
                    "malformed_metadata", "error", "Malformed quoted metadata record", span,
                ))
            elif match.lastgroup == "symbol":
                kind = next(
                    (name for name, pattern in _SYMBOLS.items() if pattern.fullmatch(raw)),
                    "unknown",
                )
                if kind == "unknown":
                    diagnostics.append(Diagnostic(
                        "unsupported_notation", "warning", f"Unrecognized BWW token {raw!r}", span,
                    ))
            else:
                kind = cast(TokenKind, match.lastgroup)
            tokens.append(Token(kind, raw, span))
        line_start = ending.end()
        line_number += 1
    return TokenizationResult(text, tuple(tokens), tuple(diagnostics))
