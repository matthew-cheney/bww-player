"""Public parser result and diagnostic types."""

from dataclasses import dataclass
from fractions import Fraction
from typing import Literal

ParseStatus = Literal["complete", "partial", "failed"]
Severity = Literal["info", "warning", "error"]
PlaybackSound = Literal["chanter", "chanter-old", "simple"]
EmbellishmentCategory = Literal[
    "grace_note", "doubling", "grip", "throw", "birl", "taorluath", "strike",
    "bubbly_note", "pele",
]


@dataclass(frozen=True, slots=True)
class SourceSpan:
    """A location in the original decoded text.

    Line and column locate the start and are one-based. Offsets are zero-based
    Python string indices with an exclusive end, so text[start:end] is the
    exact source fragment. An empty span can mark a position such as EOF.
    """

    line: int
    column: int
    start: int
    end: int
    filename: str | None = None

    def __post_init__(self) -> None:
        if self.line < 1 or self.column < 1:
            raise ValueError("line and column must be positive")
        if not 0 <= self.start <= self.end:
            raise ValueError("offsets must satisfy 0 <= start <= end")


@dataclass(frozen=True, slots=True)
class Diagnostic:
    """A parser report with a stable code and a human-readable message."""

    code: str
    severity: Severity
    message: str
    span: SourceSpan


TokenKind = Literal[
    "metadata", "header", "clef", "accidental", "time_signature", "note",
    "rest", "embellishment", "rhythmic_marker", "structural_marker", "unknown",
]


@dataclass(frozen=True, slots=True)
class Token:
    """A lexical category and its exact spelling in the source."""

    kind: TokenKind
    raw: str
    span: SourceSpan


@dataclass(frozen=True, slots=True)
class TokenizationResult:
    """Decoded source, tokens, and lexical diagnostics in source order."""

    source_text: str
    tokens: tuple[Token, ...]
    diagnostics: tuple[Diagnostic, ...]


@dataclass(frozen=True, slots=True)
class Embellishment:
    """A written grace-note movement with its original code and location."""

    code: str
    span: SourceSpan
    name: str | None = None
    category: EmbellishmentCategory | None = None
    grace_pitches: tuple[str, ...] | None = None


@dataclass(frozen=True, slots=True)
class Tuplet:
    """An interpreted tuplet with its written boundary tokens."""

    actual: int
    normal: int
    start: Token
    end: Token


@dataclass(frozen=True, slots=True)
class Tie:
    """A tie between two written notes, identified by their note tokens."""

    source: Token
    target: Token
    start: Token
    end: Token


@dataclass(frozen=True, slots=True)
class Note:
    """A melody note with exact duration in whole notes, or None if uncertain."""

    pitch: str
    duration: Fraction | None
    token: Token
    beam: Literal["r", "l"] | None = None
    embellishments: tuple[Embellishment, ...] = ()
    dot_count: int = 0
    duration_markers: tuple[Token, ...] = ()
    tuplet: Tuplet | None = None
    beam_group: SourceSpan | None = None

    @property
    def base_duration(self) -> Fraction:
        """The unmodified note value written in the source."""
        return Fraction(1, int(self.token.raw.rsplit("_", 1)[1]))


@dataclass(frozen=True, slots=True)
class Measure:
    """Notes and written measure boundaries, including incomplete measures."""

    notes: tuple[Note, ...]
    opening_barline: Token | None = None
    closing_barline: Token | None = None
    is_pickup: bool = False


@dataclass(frozen=True, slots=True)
class Part:
    """Measures in a musical section, with source markers for its system breaks."""

    measures: tuple[Measure, ...]
    staff_breaks: tuple[Token, ...] = ()


@dataclass(frozen=True, slots=True)
class Ending:
    """A numbered ending over a half-open range of written measures."""

    number: Literal[1, 2]
    start_measure: int
    stop_measure: int
    start: Token
    end: Token


@dataclass(frozen=True, slots=True)
class Repeat:
    """A two-pass repeat over a half-open range of written measures."""

    start_measure: int
    stop_measure: int
    start: Token | None
    end: Token
    endings: tuple[Ending, ...] = ()


@dataclass(frozen=True, slots=True)
class SignatureChange:
    """Written signature declarations at a measure and melody-note offset."""

    measure_index: int
    note_index: int
    tokens: tuple[Token, ...]
    meter: tuple[int, int] | None = None
    key_signature: tuple[str, ...] | None = None


@dataclass(frozen=True, slots=True)
class Tune:
    """Decoded BWW source and its interpreted score."""

    source_text: str
    title: str | None = None
    composer: str | None = None
    tune_type: str | None = None
    tempo: int | None = None
    meter: tuple[int, int] | None = None
    key_signature: tuple[str, ...] | None = None
    parts: tuple[Part, ...] = ()
    ties: tuple[Tie, ...] = ()
    repeats: tuple[Repeat, ...] = ()
    signature_changes: tuple[SignatureChange, ...] = ()

    def to_wav(self, *, bpm: float | None = None, grace_ms: float = 25,
               sound: PlaybackSound = "chanter", drone: bool = False) -> bytes:
        """Render the tune as PCM WAV bytes using the same options as play()."""
        from .playback import _events, _render

        return _render(_events(self, bpm, grace_ms), sound, drone=drone)

    def play(self, *, bpm: float | None = None, grace_ms: float = 25,
             sound: PlaybackSound = "chanter", drone: bool = False) -> None:
        """Play through the default Windows audio device and wait for completion.

        BPM defaults to the written tempo or 90. It counts dotted quarters in
        6/8, 9/8, and 12/8 and quarter notes in other meters.
        grace_ms sets the target duration of each grace note in milliseconds.
        sound selects the brighter default chanter, the original chanter-old, or the simple tone.
        drone adds sustained bass and tenor A drones when enabled.
        """
        from .playback import play

        play(self, bpm=bpm, grace_ms=grace_ms, sound=sound, drone=drone)


@dataclass(frozen=True, slots=True)
class ParseResult:
    """The available tune, diagnostics, and musical completeness.

    A complete result interprets all relevant musical input. A partial
    result has a usable tune with musical gaps. A failed result has no
    usable tune. Preserved formatting directives do not affect status.
    """

    tune: Tune | None
    diagnostics: tuple[Diagnostic, ...]
    status: ParseStatus
    source_text: str = ""
    tokens: tuple[Token, ...] = ()
    unsupported_tokens: tuple[Token, ...] = ()
    unattached_embellishments: tuple[Embellishment, ...] = ()

    def __post_init__(self) -> None:
        if (self.status == "failed") != (self.tune is None):
            raise ValueError("only failed results may omit the tune")


class ParseError(Exception):
    """Strict-mode parse failure carrying all diagnostics in report order."""

    def __init__(self, diagnostics: tuple[Diagnostic, ...]) -> None:
        self.diagnostics = diagnostics
        errors = sum(diagnostic.severity == "error" for diagnostic in diagnostics)
        super().__init__(f"BWW parsing failed with {errors} error(s)")
