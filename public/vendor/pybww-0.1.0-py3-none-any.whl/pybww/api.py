"""Public file and text entry points."""

from os import PathLike, fspath

from .lexer import tokenize_text
from .models import ParseResult, TokenizationResult
from .parser import parse_tokens


def tokenize_file(
    path: str | PathLike[str], *, encoding: str = "utf-8"
) -> TokenizationResult:
    """Decode and tokenize a BWW file, propagating I/O and decoding errors."""
    filename = fspath(path)
    with open(filename, encoding=encoding, newline="") as source:
        return tokenize_text(source.read(), filename=filename)


def parse_file(
    path: str | PathLike[str], *, encoding: str = "utf-8", strict: bool = False
) -> ParseResult:
    """Parse a BWW file using the specified encoding and preserve its line endings.

    The path supplies the filename for diagnostics. Permissive mode returns
    the available result. Strict mode raises ParseError on error diagnostics.
    """
    return parse_tokens(tokenize_file(path, encoding=encoding), fspath(path), strict)


def parse_text(
    text: str, *, filename: str | None = None, strict: bool = False
) -> ParseResult:
    """Parse decoded BWW text, optionally labeling diagnostics with a filename.

    Permissive mode returns the available result. Strict mode raises
    ParseError on error diagnostics.
    """
    return parse_tokens(tokenize_text(text, filename=filename), filename, strict)
